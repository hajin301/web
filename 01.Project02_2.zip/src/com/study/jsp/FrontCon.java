package com.study.jsp;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.study.jsp.command.BContentCommand;
import com.study.jsp.command.BDeleteCommand;
import com.study.jsp.command.BListCommand;
import com.study.jsp.command.BModifyCommand;
import com.study.jsp.command.BReplyCommand;
import com.study.jsp.command.BReplyViewCommand;
import com.study.jsp.command.BWriteCommand;

@WebServlet("*.do")
public class FrontCon extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		System.out.println("doPost");
		actionDo(request, response);
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		System.out.println("doGet");
		actionDo(request, response);
		
	}
	
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		System.out.println("actionDo");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json; charset=UTF-8");
		
		String uri = request.getRequestURI();
		System.out.println("uri : " + uri);
		String conPath = request.getContextPath();
		System.out.println("conPath : " + conPath);
		String command = uri.substring(conPath.length());
		System.out.println("command : " + command);
		
		String viewPage = null;
		HttpSession session = null;
		session = request.getSession();
		int curPage = 1;
		if (session.getAttribute("cpage") != null) {
			curPage = (int)session.getAttribute("cpage");
		}
		
		if(command.equals("/01.HW/loginOk.do")) {
			Service service = new loginOk();
			service.execute(request, response);
		} 
		else if (command.equals("/01.HW/modifyOk.do")) {
			Service service = new modifyOk();
			service.execute(request, response);
		} 
		else if (command.equals("/01.HW/joinOk.do")) {
			Service service = new joinOk();
			service.execute(request, response);
		} 
		else if (command.equals("/01.HW/logout.do")) {
			logoutOk(request, response);
		}
		//SNS 시작
		else if (command.equals("./01.HW/SNS_joinOk.do")||command.contentEquals("/SNS_joinOk.do")) {
			Service service = new SNS_joinOk();
			service.execute(request, response);	
		}
		else if (command.equals("./01.HW/SNS_loinOk.do")) {
			Service service = new SNS_loginOk();
			service.execute(request, response);
			
		}
		//BBS 시작
		else if(command.equals("/02.BBS/write_view.do")) {
			viewPage = "write_view.jsp";
		}
		else if (command.equals("/02.BBS/write.do")) {
			Service service = new BWriteCommand();
			service.execute(request, response);
			viewPage = "list.do";
		}else if(command.equals("/02.BBS/list.do")) { 
			Service service = new BListCommand();
			service .execute(request, response);
			viewPage = "list.jsp";
		}else if(command.equals("/02.BBS/content_view.do")) {
			Service service = new BContentCommand();
			service.execute(request, response);
			viewPage = "content_view.jsp";
		}else if(command.equals("/02.BBS/modify_view.do")) {
			Service service = new BContentCommand();
			service.execute(request, response);
			viewPage = "modify_view.jsp";
		}else if(command.equals("/02.BBS/Bmodify.do")) {
			Service service = new BModifyCommand();
			service.execute(request, response);
			viewPage = "list.do";
		}else if (command.equals("/02.BBS/delete.do")) {
			Service service = new BDeleteCommand();
			service.execute(request, response);
			viewPage = "list.do?page=" + curPage;
		}else if (command.equals("/02.BBS/reply_view.do")) {
			Service service = new BReplyViewCommand();
			service.execute(request, response);
			viewPage = "reply_view.jsp";
		}else if (command.equals("/02.BBS/reply.do")) {
			Service service = new BReplyCommand();
			service.execute(request, response);
			viewPage = "list.do?page=" + curPage;
		}
	
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
			
	}
	
	private void logoutOk(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		System.out.println("logout");
		
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect("login.jsp");
	}

}
